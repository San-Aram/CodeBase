// NoteService implemented with Internal Memory
import 'note_service.dart';
import '../../models/note.dart';

// class NoteServiceMock extends NoteService {}
