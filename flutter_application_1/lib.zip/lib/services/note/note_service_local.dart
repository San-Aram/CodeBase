//NoteService Implemented with Local Storage (using Shared Preference Package)

import 'dart:convert';
import 'package:shared_preferences_web/shared_preferences_web.dart';

import 'note_service.dart';
import '../../models/note.dart';

// class NoteServiceLocal extends NoteService {}
