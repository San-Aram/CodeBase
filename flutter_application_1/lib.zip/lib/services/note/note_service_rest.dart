// NoteService implemented with RESTful service.

import '../../app/service_locator.dart';
import '../rest.dart';
import 'note_service.dart';
import '../../models/note.dart';

// class NoteServiceRest extends NoteService {}
