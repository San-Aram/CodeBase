import '../../services/note/note_service.dart';

import '../../models/note.dart';
import '../../app/service_locator.dart';
import '../viewmodel.dart';

class MainViewmodel extends Viewmodel {
  List<Note>? _notes;
  List<Note>? get notes => _notes;

  int? _editIndex;
  int? get editIndex => _editIndex;
  set editIndex(value) => update(() async => _editIndex = value);
  int? get listCount {
    if (_notes == null) return 0;
    if (_notes?.length == null) return 0;
    return _notes?.length;
  }

  Note getNote(int index) => _notes![index];
}
