import 'package:flutter/material.dart';

import 'main_viewmodel.dart';
import '../view.dart';
import '../../models/note.dart';

class NoteTile extends StatelessWidget {
  const NoteTile(this.index, {super.key});

  final int index;

  @override
  Widget build(BuildContext context) {
    return SelectorView<MainViewmodel, Note>(
      selector: (_, vm) => vm.getNote(index),
      builder: (_, vm, note, __) => ListTile(
        title: Text(note.title),
        subtitle: Text(note.content),
        onLongPress: () =>
            vm.editIndex = (index == vm.editIndex) ? null : index,
        onTap: () {
          if (vm.editIndex != null) {
            // vm.updateNote(index: vm.editIndex!, data: vm.getNote(vm.editIndex!));
            vm.editIndex = null;
          }
        },
      ),
    );
  }
}
