//! This is file is meant for the first screen, i.e., ListScreen.
//! Parts of the code have been given. Complete the remaining.

import 'package:flutter/material.dart';

import 'main_app_bar.dart';
import 'main_body.dart';
import 'main_float.dart';

class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MainAppBar(),
      body: MainBody(),
      floatingActionButton: MainFloat(),
    );
  }
}
